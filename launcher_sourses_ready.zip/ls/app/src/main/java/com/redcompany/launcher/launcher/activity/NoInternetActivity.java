package com.redcompany.launcher.launcher.activity;

import android.os.Bundle;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import com.redcompany.launcher.R;

/* Копия разработана компанией "RED COMPANY" */
public class NoInternetActivity extends AppCompatActivity {
    public int progress = 0;
    private ProgressBar progressBar;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_nointernet);
    }
}
/* Григорян жирный уебан */