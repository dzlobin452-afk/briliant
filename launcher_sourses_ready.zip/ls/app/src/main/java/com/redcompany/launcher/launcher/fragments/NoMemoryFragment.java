package com.redcompany.launcher.launcher.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Config;
import com.redcompany.launcher.launcher.Utils;

/* Копия разработана компанией "RED COMPANY" */
public class NoMemoryFragment extends Fragment {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_nomemory, viewGroup, false);
        ((TextView) inflate.findViewById(R.id.text_memory)).setText("Недостаточно памяти в устройстве(" + ((int) Utils.megabytesAvailable()) + "/" + Config.SpaceAvailable + ")! Освободите, потом попробуйте снова.");
        return inflate;
    }
}
/* Григорян жирный уебан */