package com.redcompany.launcher.launcher;

import android.graphics.Bitmap;

/* Копия разработана компанией "RED COMPANY" */
public class Config {
    public static String CacheFileName = "files.zip";
    public static String DownloadDestinition = "/cache/";
    public static boolean IsCacheAlreadyDownloaded = false;
    public static String LauncherApkName = "launcher.apk";
    public static String LauncherDestinition = (DownloadDestinition + "launcher.apk");
    public static int SpaceAvailable = 0;
    public static boolean StoragePermision = false;
    public static Bitmap[] bitmapServer_config;
    public static Bitmap[] bitmap_news_image;
    public static String[] imageServer_config;
    public static String[] nameServer_config;
    public static Integer[] numberServer_config;
    public static Integer[] onlineMaxServer_config;
    public static String[] onlineServerUrl_config;
    public static String[] onlineServer_config;
    public static String url_cache_game;
    public static String url_launcher;
    public static String[] url_news_button;
    public static String[] url_news_image;
    public static String[] url_news_text;
    public static int version_launcher;
}
/* Григорян жирный уебан */