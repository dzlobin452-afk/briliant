package com.redcompany.launcher.launcher.activity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Config;
import com.redcompany.launcher.launcher.Utils;
import com.redcompany.launcher.launcher.fragments.NoMemoryFragment;
import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.Progress;
import com.google.firebase.messaging.Constants;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/* Копия разработана компанией "RED COMPANY" */
public class DownloadActivity extends AppCompatActivity {
    TextView download_megabyte;
    File fDownloadDir;
    ProgressBar progressBar;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_download);
        final Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.click);
        getWindow().addFlags(128);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        this.download_megabyte = (TextView) findViewById(R.id.download_megabyte);
        this.progressBar = (ProgressBar) findViewById(R.id.progressBar);
        ArrayList arrayList = new ArrayList();
        arrayList.add("RED COMPANY не использует ботов.");
        arrayList.add("Администрация никогда не будет просить у вас пароль ни в коем случае!");
        arrayList.add("Разработчики стараются для вас.");
        arrayList.add("RED COMPANY чаще всех выпускает обновления");
        ((Button) findViewById(R.id.start_download)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view.startAnimation(loadAnimation);
                if (Utils.megabytesAvailable() < ((float) Config.SpaceAvailable)) {
                    new Thread(new Runnable() {
                        public void run() {
                            try {
                                DownloadActivity.this.getSupportFragmentManager().beginTransaction().replace(R.id.main_download_layout, new NoMemoryFragment()).addToBackStack((String) null).commitAllowingStateLoss();
                            } catch (IllegalStateException unused) {
                            }
                        }
                    }).start();
                    return;
                }
                DownloadActivity.this.findViewById(R.id.soglashenie_download).setVisibility(View.GONE);
                DownloadActivity.this.progressBar.setVisibility(View.VISIBLE);
                DownloadActivity.this.download_megabyte.setVisibility(View.VISIBLE);
                DownloadActivity.this.findViewById(R.id.textView21).setVisibility(View.GONE);
                DownloadActivity.this.findViewById(R.id.textView11).setVisibility(View.GONE);
                DownloadActivity.this.fDownloadDir = new File(DownloadActivity.this.getExternalFilesDir((String) null), "downloads");
                if (!DownloadActivity.this.fDownloadDir.exists()) {
                    DownloadActivity.this.fDownloadDir.mkdirs();
                }
                Log.d("InfoJSON", "" + DownloadActivity.this.fDownloadDir.toString());
                if (new File(DownloadActivity.this.fDownloadDir.toString() + "/" + Config.CacheFileName).exists()) {
                    Config.IsCacheAlreadyDownloaded = true;
                }
                if (Config.IsCacheAlreadyDownloaded) {
                    DownloadActivity.this.startUnZipping();
                } else {
                    DownloadActivity.this.InstallCache();
                }
            }
        });
    }

    public void InstallCache() {
        PRDownloader.download(Config.url_cache_game, this.fDownloadDir.toString(), Config.CacheFileName).build().setOnStartOrResumeListener((OnStartOrResumeListener) null).setOnPauseListener((OnPauseListener) null).setOnCancelListener((OnCancelListener) null).setOnProgressListener(new OnProgressListener() {
            public void onProgress(Progress progress) {
                DownloadActivity.this.progressBar.setMax((int) Utils.bytesToMeg(progress.totalBytes));
                DownloadActivity.this.progressBar.setProgress((int) Utils.bytesToMeg(progress.currentBytes));
                DownloadActivity.this.progressBar.setIndeterminate(false);
                TextView textView = DownloadActivity.this.download_megabyte;
                textView.setText(((int) Utils.bytesToMeg(progress.currentBytes)) + "/" + ((int) Utils.bytesToMeg(progress.totalBytes)) + "MB");
            }
        }).start(new OnDownloadListener() {
            public void onDownloadComplete() {
                DownloadActivity.this.progressBar.setVisibility(View.GONE);
                DownloadActivity.this.progressBar.setIndeterminate(true);
                DownloadActivity.this.progressBar.setVisibility(View.VISIBLE);
                DownloadActivity.this.startUnZipping();
            }

            public void onError(Error error) {
                Log.d("InfoJSON", "download error " + Config.url_cache_game + " " + error.getServerErrorMessage());
                DownloadActivity.this.InstallCache();
            }
        });
    }

    public void startUnZipping() {
        UnZip unZip = new UnZip(this);
        unZip.execute(new String[]{this.fDownloadDir.toString() + "/" + Config.CacheFileName, getExternalFilesDir((String) null) + "/"});
    }

    private class UnZip extends AsyncTask<String, Integer, String> {
        private Context context;
        private long element;

        public UnZip(Context context2) {
            this.context = context2;
        }

        public String doInBackground(String... strArr) {
            String str = strArr[0];
            int length = (int) new File(str).length();
            try {
                File file = new File(strArr[1]);
                if (file.exists()) {
                    file.delete();
                } else {
                    file.mkdirs();
                    file.createNewFile();
                }
                if (!new File(str).exists()) {
                    System.out.println("Pizda");
                }
                ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(str));
                while (true) {
                    ZipEntry nextEntry = zipInputStream.getNextEntry();
                    if (nextEntry != null) {
                        float compressedSize = ((float) nextEntry.getCompressedSize()) + 0.0f;
                        nextEntry.getSize();
                        Log.d("tag", "ze=" + nextEntry.getName() + " " + nextEntry.getSize());
                        String name = nextEntry.getName();
                        if (nextEntry.isDirectory()) {
                            mkdirs(file, name);
                        } else {
                            String dirpart = dirpart(name);
                            if (dirpart != null) {
                                mkdirs(file, dirpart);
                            }
                            byte[] bArr = new byte[4096];
                            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(new File(file, name)));
                            while (true) {
                                int read = zipInputStream.read(bArr);
                                if (read == -1) {
                                    break;
                                }
                                bufferedOutputStream.write(bArr, 0, read);
                            }
                            if (-1.0f != (compressedSize / ((float) length)) * 100.0f) {
                                DownloadActivity.this.runOnUiThread(new Runnable() {
                                    public void run() {
                                        DownloadActivity.this.progressBar.setIndeterminate(true);
                                        DownloadActivity.this.download_megabyte.setText("Ожидайте");
                                    }
                                });
                            }
                            bufferedOutputStream.close();
                        }
                    } else {
                        zipInputStream.close();
                        return null;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("tag", Constants.IPC_BUNDLE_KEY_SEND_ERROR, e);
                return null;
            }
        }

        public void onPreExecute() {
            super.onPreExecute();
        }

        public void onProgressUpdate(Integer... numArr) {
            super.onProgressUpdate(numArr);
        }

        public void onPostExecute(String str) {
            Toast.makeText(DownloadActivity.this.getApplicationContext(), "Загрузка  завершена.", 0).show();
            DownloadActivity.this.progressBar.setIndeterminate(true);
            Intent intent = new Intent();
            intent.setClass(DownloadActivity.this.getApplicationContext(), MainActivity.class);
            DownloadActivity.this.startActivity(intent);
            new File(DownloadActivity.this.fDownloadDir.toString() + "/" + Config.CacheFileName).delete();
        }

        private void mkdirs(File file, String str) {
            File file2 = new File(file, str);
            if (!file2.exists()) {
                file2.mkdirs();
            }
        }

        private String dirpart(String str) {
            int lastIndexOf = str.lastIndexOf(File.separatorChar);
            if (lastIndexOf == -1) {
                return null;
            }
            return str.substring(0, lastIndexOf);
        }
    }
}
/* Григорян жирный уебан */