package com.redcompany.launcher.launcher.activity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Config;
import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.Progress;
import java.io.File;

/* Копия разработана компанией "RED COMPANY" */
public class UpdateLauncherActivity extends AppCompatActivity {
    private Button button_update;

    public ProgressBar progressBar;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_updatelauncher);
        final Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.click);
        new File(getApplicationContext().getExternalFilesDir((String) null) + Config.LauncherDestinition).delete();
        this.button_update = (Button) findViewById(R.id.button_update);
        ProgressBar progressBar2 = (ProgressBar) findViewById(R.id.progressBar);
        this.progressBar = progressBar2;
        progressBar2.setVisibility(View.GONE);
        this.button_update.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view.startAnimation(loadAnimation);
                UpdateLauncherActivity.this.findViewById(R.id.soglashenie_update).setVisibility(View.GONE);
                UpdateLauncherActivity.this.progressBar.setVisibility(View.VISIBLE);
                UpdateLauncherActivity.this.UpdateLauncher();
            }
        });
    }

    public void UpdateLauncher() {
        String str = Config.url_launcher;
        PRDownloader.download(str, getApplicationContext().getExternalFilesDir((String) null) + Config.DownloadDestinition, Config.LauncherApkName).build().setOnStartOrResumeListener((OnStartOrResumeListener) null).setOnPauseListener((OnPauseListener) null).setOnCancelListener((OnCancelListener) null).setOnProgressListener(new OnProgressListener() {
            public void onProgress(Progress progress) {
                UpdateLauncherActivity.this.progressBar.setMax((int) (progress.totalBytes / 100));
                UpdateLauncherActivity.this.progressBar.setProgress((int) (progress.currentBytes / 100));
            }
        }).start(new OnDownloadListener() {
            public void onDownloadComplete() {
                UpdateLauncherActivity.this.installApk();
            }

            public void onError(Error error) {
                Log.d("InfoJSON", "download error " + Config.url_launcher + " " + error.getResponseCode());
            }
        });
    }

    public void installApk() {
        Context applicationContext = getApplicationContext();
        Uri uriForFile = FileProvider.getUriForFile(applicationContext, "com.brilliant.bonus.provider", new File(getApplicationContext().getExternalFilesDir((String) null) + Config.LauncherDestinition));
        Intent intent = new Intent("android.intent.action.VIEW", uriForFile);
        intent.setDataAndType(uriForFile, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);
    }
}
/* Григорян жирный уебан */