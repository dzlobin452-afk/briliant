package com.redcompany.launcher.core;

public interface ISaveableFragment {
    public void save();
    public void getValues();
}
