package com.redcompany.launcher.launcher.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.fragment.app.Fragment;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Utils;
import com.redcompany.launcher.launcher.activity.DownloadActivity;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import java.io.File;
import java.io.IOException;
import org.ini4j.Wini;

/* Копия разработана компанией "RED COMPANY" */
public class SettingsFragment extends Fragment {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_settings, viewGroup, false);
        EditText editText = (EditText) inflate.findViewById(R.id.settings_nickname);
        final Animation loadAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.click);
        File file = new File(getActivity().getExternalFilesDir((String) null) + "/SAMP/settings.ini");
        if (file.exists()) {
            try {
                Wini wini = new Wini(file);
                String str = wini.get("client", AppMeasurementSdk.ConditionalUserProperty.NAME);
                editText.setText(str);
                if (str == " ") {
                    editText.setText("Nick_Name");
                }
                wini.store();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        editText.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                String charSequence2 = charSequence.toString();
                File file = new File(SettingsFragment.this.getActivity().getExternalFilesDir((String) null) + "/SAMP/settings.ini");
                if (file.exists()) {
                    try {
                        Wini wini = new Wini(file);
                        wini.put("client", AppMeasurementSdk.ConditionalUserProperty.NAME, charSequence2);
                        wini.store();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ((Button) inflate.findViewById(R.id.button_reinstall)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view.startAnimation(loadAnimation);
                Utils.delete(new File(SettingsFragment.this.getActivity().getExternalFilesDir((String) null) + "/"));
                SettingsFragment.this.startActivity(new Intent(SettingsFragment.this.getActivity(), DownloadActivity.class));
                SettingsFragment.this.getActivity().finish();
            }
        });
        ((ImageView) inflate.findViewById(R.id.button_back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SettingsFragment.this.getActivity().onBackPressed();
            }
        });
        return inflate;
    }
}
/* Григорян жирный уебан */