package com.redcompany.launcher.launcher.activity;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Config;
import com.redcompany.launcher.launcher.Utils;
import com.redcompany.launcher.launcher.fragments.HomeFragment;

/* Копия разработана компанией "RED COMPANY" */
public class MainActivity extends AppCompatActivity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        if (1 < Config.version_launcher) {
            startActivity(new Intent(this, UpdateLauncherActivity.class));
            finish();
        }
        if (!Utils.IsCacheExists(getApplicationContext())) {
            startActivity(new Intent(this, DownloadActivity.class));
            finish();
        }
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.fragment_place, new HomeFragment());
        beginTransaction.addToBackStack((String) null);
        beginTransaction.commit();
    }
}
/* Григорян жирный уебан */