package com.redcompany.launcher.launcher.network;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Config;
import com.redcompany.launcher.launcher.activity.MainActivity;
import com.redcompany.launcher.launcher.adapter.ServerAdapter;
import com.bumptech.glide.Glide;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* Копия разработана компанией "RED COMPANY" */
public class HTTPRequest {

    public Activity activity;

    public HTTPRequest(Activity activity2) {
        this.activity = activity2;
        Start();
    }

    public void Start() {
        Volley.newRequestQueue(this.activity).add(new StringRequest(0, "http://188.127.241.74/launcher/game.json", new Response.Listener<String>() {
            public void onResponse(String str) {
                try {
                    HTTPRequest.getGameInfo(new JSONObject(str).getJSONObject("game"));
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d("InfoJSON", "error game");
                }
            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                Log.d("InfoJSON", "error game");
            }
        }));
        Volley.newRequestQueue(this.activity).add(new StringRequest(0, "http://188.127.241.74/launcher/server.json", new Response.Listener<String>() {
            public void onResponse(String str) {
                try {
                    HTTPRequest.getServerInfo(new JSONObject(str).getJSONArray("server"));
                    HTTPRequest.this.getFullData();
                    HTTPRequest.this.LoadAllSizeArchive();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d("InfoJSON", "error server");
                }
            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                Log.d("InfoJSON", "error server");
            }
        }));
    }

    static void getGameInfo(JSONObject jSONObject) throws JSONException {
        Config.url_launcher = jSONObject.getString("url_launcher");
        Config.version_launcher = jSONObject.getInt("version_launcher");
        Config.SpaceAvailable = jSONObject.getInt("space_available");
        Config.url_cache_game = jSONObject.getString("url_cache");
    }

    static void getServerInfo(JSONArray jSONArray) throws JSONException {
        Config.numberServer_config = new Integer[jSONArray.length()];
        Config.nameServer_config = new String[jSONArray.length()];
        Config.onlineServerUrl_config = new String[jSONArray.length()];
        Config.onlineMaxServer_config = new Integer[jSONArray.length()];
        Config.imageServer_config = new String[jSONArray.length()];
        Config.bitmapServer_config = new Bitmap[jSONArray.length()];
        for (int i = 0; i < jSONArray.length(); i++) {
            Config.numberServer_config[i] = Integer.valueOf(jSONArray.getJSONObject(i).getInt("number_server"));
            Config.nameServer_config[i] = jSONArray.getJSONObject(i).getString("name_server");
            Config.onlineServerUrl_config[i] = jSONArray.getJSONObject(i).getString("online_server");
            Config.onlineMaxServer_config[i] = Integer.valueOf(jSONArray.getJSONObject(i).getInt("maxonline_server"));
            Config.imageServer_config[i] = jSONArray.getJSONObject(i).getString("imagelink_server");
        }
    }

    public void LoadAllSizeArchive() {
        new Thread() {
            public void run() {
                for (int i = 0; i < Config.imageServer_config.length; i++) {
                    Config.bitmapServer_config[i] = HTTPRequest.this.getBitmapFromURL(Config.imageServer_config[i]);
                }
                HTTPRequest.this.activity.startActivity(new Intent(HTTPRequest.this.activity, MainActivity.class));
                HTTPRequest.this.activity.finish();
            }
        }.start();
    }


    public void getFullData() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient(true, 80, 443);
        asyncHttpClient.addHeader("Content-Type", "text/xml; charset=utf-8");
        for (int i = 0; i < Config.onlineServerUrl_config.length; i++) {
            Config.onlineServer_config = new String[Config.onlineServerUrl_config.length];
            asyncHttpClient.get(Config.onlineServerUrl_config[i], new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                }

                @Override
                public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                }

                public void onSuccess(int i, Header[] headerArr, byte[] bArr) {
                    ServerAdapter serverAdapter;
                    String str = new String(bArr);
                    str.replace("0", "null");
                    Config.onlineServer_config[i] = str;
                    RecyclerView recyclerView = (RecyclerView) HTTPRequest.this.activity.findViewById(R.id.server_recycler);
                    if (recyclerView != null && (serverAdapter = (ServerAdapter) recyclerView.getAdapter()) != null) {
                        serverAdapter.notifyItemChanged(i);
                    }
                }

                public void onFailure(int i, Header[] headerArr, byte[] bArr, Throwable th) {
                    Log.d("InfoJSON", "error " + th.toString());
                }
            });
        }
    }

    public Bitmap getBitmapFromURL(String str) {
        try {
            return (Bitmap) Glide.with(this.activity).asBitmap().load(str).submit().get();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
/* Григорян жирный уебан */