package com.redcompany.launcher.launcher.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.redcompany.launcher.R;
import java.util.ArrayList;

/* Копия разработана компанией "RED COMPANY" */
public class ServerAdapter extends RecyclerView.Adapter<ServerAdapter.ViewHolder> {
    public ArrayList<Bitmap> mBitmapImage;
    public Context mContext;
    public ArrayList<Integer> mMaxonline;
    public ArrayList<String> mName;
    public ArrayList<Integer> mNumber;
    public ArrayList<String> mOnline;

    public ServerAdapter(Context context, ArrayList<Integer> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3, ArrayList<Integer> arrayList4, ArrayList<Bitmap> arrayList5) {
        this.mContext = context;
        this.mNumber = arrayList;
        this.mName = arrayList2;
        this.mOnline = arrayList3;
        this.mMaxonline = arrayList4;
        this.mBitmapImage = arrayList5;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.server_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.mServerBg.setBackground(new BitmapDrawable(this.mContext.getResources(), this.mBitmapImage.get(i)));
        viewHolder.mServerNameText.setText(this.mName.get(i));
        viewHolder.mOnlineText.setText(Html.fromHtml(this.mOnline.get(i) + "/" + this.mMaxonline.get(i)), TextView.BufferType.SPANNABLE);
    }

    public int getItemCount() {
        return this.mName.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView mOnlineText;
        public ImageView mServerBg;
        public TextView mServerNameText;
        private View mView;

        public ViewHolder(View view) {
            super(view);
            this.mView = view;
            this.mServerBg = (ImageView) view.findViewById(R.id.server_bg);
            this.mServerNameText = (TextView) view.findViewById(R.id.textView6);
            this.mOnlineText = (TextView) view.findViewById(R.id.online_text);
        }

        public View getView() {
            return this.mView;
        }
    }
}
/* Григорян жирный уебан */