package com.redcompany.launcher.launcher.network;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.widget.RemoteViews;
import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import androidx.core.app.NotificationCompat;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.activity.SplashActivity;
import com.bumptech.glide.Glide;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.concurrent.ExecutionException;

/* Копия разработана компанией "RED COMPANY" */
public class FirebaseMessageReceiver extends FirebaseMessagingService {
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (remoteMessage.getData().size() > 0) {
            showNotification(remoteMessage.getData().get("title"), remoteMessage.getData().get("message"), remoteMessage.getData().get("image"));
        }
        if (remoteMessage.getNotification() == null) {
            return;
        }
        if (remoteMessage.getNotification().getImageUrl() != null) {
            showNotification(remoteMessage.getNotification().getTitle(), remoteMessage.getNotification().getBody(), remoteMessage.getNotification().getImageUrl().toString());
        } else {
            showNotificationNoImage(remoteMessage.getNotification().getTitle(), remoteMessage.getNotification().getBody());
        }
    }

    private RemoteViews getCustomDesign(String str, String str2, String str3) {
        RemoteViews remoteViews = new RemoteViews(getApplicationContext().getPackageName(), R.layout.notification);
        remoteViews.setTextViewText(R.id.title, str);
        remoteViews.setTextViewText(R.id.message, str2);
        remoteViews.setImageViewBitmap(R.id.icon, getBitmapFromURL(str3));
        return remoteViews;
    }

    public void showNotification(String str, String str2, String str3) {
        NotificationCompat.Builder builder;
        Intent intent = new Intent(this, SplashActivity.class);
        intent.putExtra("notif_message", str2);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
        Uri defaultUri = RingtoneManager.getDefaultUri(2);
        NotificationCompat.Builder contentIntent = new NotificationCompat.Builder(getApplicationContext(), "web_app_channel").setSmallIcon(R.mipmap.ic_launcher).setSound(defaultUri).setAutoCancel(true).setVibrate(new long[]{1000, 1000, 1000, 1000, 1000}).setOnlyAlertOnce(true).setContentIntent(activity);
        if (Build.VERSION.SDK_INT >= 16) {
            builder = contentIntent.setContent(getCustomDesign(str, str2, str3));
        } else {
            builder = contentIntent.setContentTitle(str).setContentText(str2).setContentIntent(activity).setSmallIcon(R.mipmap.ic_launcher);
        }
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("web_app_channel", "web_app", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setSound(defaultUri, (AudioAttributes) null);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        notificationManager.notify(0, builder.build());
    }

    public void showNotificationNoImage(String str, String str2) {
        Intent intent = new Intent(this, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
        Uri defaultUri = RingtoneManager.getDefaultUri(2);
        NotificationCompat.Builder smallIcon = new NotificationCompat.Builder(getApplicationContext(), "web_app_channel").setSmallIcon(R.mipmap.ic_launcher).setSound(defaultUri).setAutoCancel(true).setVibrate(new long[]{1000, 1000, 1000, 1000, 1000}).setOnlyAlertOnce(true).setContentIntent(activity).setContentTitle(str).setContentText(str2).setSmallIcon(R.mipmap.ic_launcher);
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("web_app_channel", "web_app", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setSound(defaultUri, (AudioAttributes) null);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        notificationManager.notify(0, smallIcon.build());
    }

    public Bitmap getBitmapFromURL(String str) {
        try {
            return (Bitmap) Glide.with((Context) this).asBitmap().load(str).submit().get();
        } catch (InterruptedException e) {
            e.printStackTrace();
            return null;
        } catch (ExecutionException e2) {
            e2.printStackTrace();
            return null;
        }
    }
}
/* Григорян жирный уебан */