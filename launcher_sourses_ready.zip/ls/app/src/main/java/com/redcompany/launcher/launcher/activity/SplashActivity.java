package com.redcompany.launcher.launcher.activity;

import android.content.Intent;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.redcompany.launcher.R;
import com.redcompany.launcher.launcher.Config;
import com.redcompany.launcher.launcher.Utils;
import com.redcompany.launcher.launcher.network.HTTPRequest;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import java.util.Objects;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/* Копия разработана компанией "RED COMPANY" */
public class SplashActivity extends AppCompatActivity implements GLSurfaceView.Renderer {
    public int progress = 0;
    private ProgressBar progressBar;

    public void onSurfaceChanged(GL10 gl10, int i, int i2) {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_splash);
        PRDownloader.initialize(getApplicationContext(), PRDownloaderConfig.newBuilder().setDatabaseEnabled(true).setReadTimeout(30000).setConnectTimeout(30000).build());
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 200);
        } else {
            initGL();
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 200 && strArr.length > 0 && iArr[0] == 0) {
            initGL();
        } else if (!Config.StoragePermision) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(getLayoutInflater().inflate(R.layout.no_storage, (ViewGroup) null));
            AlertDialog create = builder.create();
            Window window = create.getWindow();
            Objects.requireNonNull(window);
            window.setBackgroundDrawableResource(R.drawable.bg_re2);
            window.setGravity(17);
            create.setCancelable(false);
            create.show();
        }
    }

    public void initGL() {
        Config.StoragePermision = true;
        if (Utils.isNetworkConnected(this)) {
            GLSurfaceView gLSurfaceView = new GLSurfaceView(this);
            gLSurfaceView.setRenderer(this);
            gLSurfaceView.setLayoutParams(new LinearLayout.LayoutParams(1, 1));
            ((ConstraintLayout) findViewById(R.id.main_splash_layout)).addView(gLSurfaceView);
        } else if (!Utils.internetIsConnected()) {
            startActivity(new Intent(this, NoInternetActivity.class));
            finish();
        }
    }

    public void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
        gl10.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
        new HTTPRequest(this);
    }

    public void onDrawFrame(GL10 gl10) {
        gl10.glClear(16384);
    }
}
/* Григорян жирный уебан */