package com.redcompany.launcher.launcher;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.io.File;
import java.nio.charset.StandardCharsets;

/* Копия разработана компанией "RED COMPANY" */
public class Utils {
    private static final long MEGABYTE = 1048576;
    public static AlphaAnimation buttonClick = new AlphaAnimation(1.0f, 0.8f);

    public static String info;

    public static boolean IsCacheExists(Context context) {
        String str = context.getExternalFilesDir((String) null) + "/";
        File file = new File(str + "anim/");
        File file2 = new File(str + "audio/");
        File file3 = new File(str + "data/");
        File file4 = new File(str + "models/");
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("texdb/");
        return file.exists() && file2.exists() && file3.exists() && file4.exists() && new File(sb.toString()).exists();
    }

    public static long bytesToMeg(long j) {
        return j / MEGABYTE;
    }

    public static String getDataFromURL(final Context context, String str) {
        Log.d("InfoJSON", "getDataFromURL: " + str);
        Volley.newRequestQueue(context).add(new StringRequest(0, str, new Response.Listener<String>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            public void onResponse(String str) {
                Log.d("InfoJSON", "getDataFromURL: " + str);
                String unused = Utils.info = new String(str.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(context, "nothing", Toast.LENGTH_SHORT).show();
            }
        }));
        return info;
    }

    public static void delete(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
                for (File delete : file.listFiles()) {
                    delete(delete);
                }
            }
            file.delete();
        }
    }

    public static boolean isNetworkConnected(Context context) {
        return ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo() != null;
    }

    public static boolean internetIsConnected() {
        try {
            return Runtime.getRuntime().exec("ping -c 1 google.com").waitFor() == 0;
        } catch (Exception unused) {
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    public static float megabytesAvailable() {
        StatFs statFs = new StatFs(new File(Environment.getExternalStorageDirectory().getPath()).getPath());
        return ((float) (statFs.getBlockSizeLong() * statFs.getAvailableBlocksLong())) / 1048576.0f;
    }
}
/* Григорян жирный уебан */