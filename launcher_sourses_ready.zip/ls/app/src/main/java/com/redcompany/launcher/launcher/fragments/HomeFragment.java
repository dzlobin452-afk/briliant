package com.redcompany.launcher.launcher.fragments;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.redcompany.launcher.R;
import com.redcompany.launcher.GTASA;
import com.redcompany.launcher.launcher.Config;
import com.redcompany.launcher.launcher.adapter.ServerAdapter;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.ini4j.Wini;

/* Копия разработана компанией "RED COMPANY" */
public class HomeFragment extends Fragment {
    ArrayList<Bitmap> image = null;
    private ServerAdapter mServerAdaper;
    private RecyclerView mServerRecycler;
    ArrayList<String> nameText = null;
    ArrayList<Integer> numberText = null;
    ArrayList<Integer> onlineMaxText = null;
    ArrayList<String> onlineText = null;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_home, viewGroup, false);
        this.mServerRecycler = (RecyclerView) inflate.findViewById(R.id.server_recycler);
        final Animation loadAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.click);
        this.numberText = new ArrayList<>();
        this.nameText = new ArrayList<>();
        this.onlineText = new ArrayList<>();
        this.onlineMaxText = new ArrayList<>();
        this.image = new ArrayList<>();
        for (int i = 0; i < Config.numberServer_config.length; i++) {
            this.numberText.add(Config.numberServer_config[i]);
            this.nameText.add(Config.nameServer_config[i]);
            this.onlineText.add(Config.onlineServer_config[i]);
            this.onlineMaxText.add(Config.onlineMaxServer_config[i]);
            this.image.add(Config.bitmapServer_config[i]);
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        this.mServerRecycler.setLayoutManager(linearLayoutManager);
        ServerAdapter serverAdapter = new ServerAdapter(getContext(), this.numberText, this.nameText, this.onlineText, this.onlineMaxText, this.image);
        this.mServerAdaper = serverAdapter;
        this.mServerRecycler.setAdapter(serverAdapter);
        ((Button) inflate.findViewById(R.id.start_game)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view.startAnimation(loadAnimation);
                File file = new File(HomeFragment.this.getActivity().getExternalFilesDir((String) null) + "/SAMP/settings.ini");
                if (file.exists()) {
                    try {
                        Wini wini = new Wini(file);
                        if (!wini.get("client", AppMeasurementSdk.ConditionalUserProperty.NAME).contains("_")) {
                            Toast.makeText(HomeFragment.this.getActivity(), "Ошибка, ваш ник-нейм написан неправильно", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        wini.store();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                HomeFragment.this.startActivity(new Intent(HomeFragment.this.getActivity(), GTASA.class));
            }
        });
        ((ImageView) inflate.findViewById(R.id.settings_button)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                FragmentTransaction beginTransaction = HomeFragment.this.getActivity().getSupportFragmentManager().beginTransaction();
                beginTransaction.replace(R.id.fragment_place, new SettingsFragment());
                beginTransaction.addToBackStack((String) null);
                beginTransaction.commit();
            }
        });
        ((Button) inflate.findViewById(R.id.button_site)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view.startAnimation(loadAnimation);
                HomeFragment.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://brilliantbonus.online/")));
            }
        });
        ((Button) inflate.findViewById(R.id.button_vk)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                view.startAnimation(loadAnimation);
                HomeFragment.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://vk.com/brilliant.game")));
            }
        });
        return inflate;
    }
}
/* Григорян жирный уебан */